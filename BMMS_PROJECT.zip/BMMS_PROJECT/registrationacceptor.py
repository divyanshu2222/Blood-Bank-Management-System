# Importing
import sqlite3
from tkinter import *
from imp import reload
from PIL import ImageTk,Image
from tkinter import Tk, StringVar, messagebox, ttk, END, IntVar, DISABLED, NORMAL

root = Tk()
root.title("Blood Bank Management System")      # Set Title
root.iconbitmap('images\\icon1.ico')            # Set Icon
root.geometry("1199x600+100+50")                # Set Geometry
root.resizable(False,False)                     # Disable the resizable Property
root.configure(bg='#f1053c')                    # Set bg Color

# Set BackGround Image
img1 = Image.open("images\\images.jpeg")
img1 = img1.resize((600,670))
my1 =ImageTk.PhotoImage(img1)
label1 = Label(image=my1).place(x=600,y=0)

# Menu Function
def back():
    root.destroy()
    import page2
    reload(page2)

# create a Menubar
menubar = Menu(root)
root.config(menu=menubar)
user_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label='BACK',command=back)      # add menu items to the File menu

# Create Variables
Fullname = StringVar()
email = StringVar()
mobile = StringVar()
address = StringVar()
gender = StringVar()
age = StringVar()
blood_group = StringVar()
blood_unit = StringVar()
chktc = IntVar()
description = StringVar()

# Function to Clear Form After Submit
def clear_data():
    entry_1.delete(0, END)
    entry_1_1.delete(0, END)
    entry_2.delete(0, END)
    entry_2_1.delete(0, END)
    entry_2_3.delete(0, END)
    combo_gender.current(0)
    combo_blood.current(0)
    entry_6.delete(0, END)
    entry_7.delete(0, END)

# Register Button Function
def insert_record():
    print(Fullname.get(), email.get(), mobile.get(), address.get(), gender.get(), age.get() ,blood_group.get(), blood_unit.get(),description.get())
    if Fullname.get() == "" or email.get() == "" or mobile.get() == "" or address.get() == "" or gender.get() == "" or age.get() == "" or blood_group.get() == "" or blood_unit.get() == "" or description.get()=="":
        messagebox.showerror("Error !", "All Fields are Required !")
    else:
        import dbconnect
        conn = dbconnect.getsqliteconnection()        # Connect to sqlite database
        try:
            cur = conn.cursor()
            cur.execute("select * from Receiver_detail where Emailid=?", (email.get(),))
            row = cur.fetchone()
            if row != None:
                entry_2_1.delete(0, END)
                messagebox.showerror("Error !", "Already Exists Email ! Try with another one.")
            # elif int(age.get()>=18 and age.get()<=65 :
            #     pass
            # else:
            #     print("\tYou cannot Donate!!!")
              
            # elif len(self.mobileno)==10 and self.mobileno.isdigit() :
            #     pass
            # else:
            #     print("\tEntered wrong number")    
            # elif(self.email.count('@')==1  and '.' in self.email ):
            #     pass
            # else:
            #     print("\tPlease enter Valid email !!!") 
            else:    
                query = ('insert into Receiver_detail(Fullname, Emailid, MobileNo, Address, Gender, Age, Blood_group, Blood_unit, Description)'
                         'values (:fname1, :email1, :mobile1, :addr1, :gender1, :age1, :bloodg, :bloodu, :des);')
                params = {
                    'fname1': Fullname.get(),
                    'email1': email.get(),
                    'mobile1': mobile.get(),
                    'addr1': address.get(),
                    'gender1': gender.get(),
                    'age1': age.get(),
                    'bloodg': blood_group.get(),
                    'bloodu': blood_unit.get(),
                    'des': description.get() 
                        }

                conn.execute(query, params)
                conn.commit()
                messagebox.showinfo("Success !", "Registration Completed !")
                clear_data()
        except sqlite3.Error as error:
                print("Problem with SQlite table", error)
        finally:
            if conn:
                conn.close()
                print("The SQLite connection is closed")

# Function that checks chkbox is checked or not   
def isChecked():
        if chktc.get() == 1:
           reg_btn['state'] = NORMAL
           reg_btn.configure(text='Submit')
        elif chktc.get() == 0:
           reg_btn['state'] = DISABLED
           reg_btn.configure(text='Check T & C!')
    
# Label 0
label_0 = Label(root, text="RECEIVER REGISTRATION",font=("times new roman", 28, "bold"),fg="white",bg="#f1053c").place(x=50,y=30)

# Label 1
label_1 = Label(root, text="PATIENT  NAME",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=110)
entry_1 = Entry(root,textvar=Fullname,width=32)
entry_1.place(x=270,y=110)

# Label 2
label_1_1 = Label(root, text="ADDRESS",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=140)
entry_1_1 = Entry(root,textvar=address,width=32)
entry_1_1.place(x=270,y=140)

# Label 3
label_2 = Label(root, text="MOBILE  NO",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=170)
entry_2 = Entry(root,textvar=mobile,width=32)
entry_2.place(x=270,y=170)

# Label 4
label_2_1 = Label(root, text="EMAIL",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=200)
entry_2_1 = Entry(root,textvar=email,width=32)
entry_2_1.place(x=270,y=200)

# Label 5
label_3 = Label(root,text="GENDER",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=230)
combo_gender = ttk.Combobox(root, textvariable=gender)
combo_gender['values'] = ('Male','Female','Transgender')
combo_gender.current(0) # Default 'Male' WILL SELECTED
combo_gender.place(x=270,y=230, width=200)

# Label 6
label_4 = Label(root, text="AGE",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=270)
entry_2_3 = Entry(root,textvar=age,width=32)
entry_2_3.place(x=270,y=270)

# Label 7
label_5 = Label(root, text="BlOOD  GROUP", font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80, y=310)
combo_blood = ttk.Combobox(root, textvariable=blood_group)
combo_blood['values'] = ('A+','B+','O+','A-','B-','AB+','AB-','O-')
combo_blood.current(0) # Default A+ WILL SELECTED
combo_blood.place(x=270, y=310, width=200)

# Label 8
label_6 = Label(root, text="BlOOD UNIT",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=340)
entry_6 =Entry(root,textvar=blood_unit,width=32)
entry_6.place(x=270,y=340)

# Label 9
label_7 = Label(root, text="DESCRIPTION",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=370)
entry_7 =Entry(root,textvar=description,width=32)
entry_7.place(x=270,y=372,height=60)

# Chkbox
chk = Checkbutton(root, text="I Agree the Terms & Conditions",font=("times new roman",15,"bold"),fg="white",bg="#f1053c", variable=chktc, onvalue=1, offvalue=0, command=isChecked).place(x=130, y=450)

# Style Button
style = ttk.Style()
style.configure('TButton',width=20 )
reg_btn = ttk.Button(root, text='Submit', style='TButton', state=DISABLED, command=insert_record)
reg_btn.place(x=200,y=500)

root.mainloop()         # mainloop() is used to load the GUI Window