# Importing
import sqlite3
from tkinter import *
from imp import reload
from PIL import ImageTk,Image,ImageDraw
from tkinter import Tk, StringVar,ttk, messagebox, END, IntVar, DISABLED, NORMAL

root = Tk()
root.title("Blood Bank Management System")          # Set Title
root.iconbitmap('images\\icon1.ico')                # Set Icon
root.geometry("1199x600+100+50")                    # Set Geometry
root.resizable(False,False)                         # Disable the resizable Property
root.configure(bg='#f1053c')                        # Set Background Color

# Set BackGround Image
img = Image.open("images\\donregis.png")
img = img.resize((595,630))
my =ImageTk.PhotoImage(img)
label = Label(image=my).place(x=600,y=0)

# Menu Function
def login():
    root.destroy()
    import main
    reload(main)

# create a Menubar
menubar = Menu(root)
root.config(menu=menubar)
user_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label='BACK',command=login)         # add menu items to the File menu

# Create Variables        
Fullname = StringVar()
user = StringVar()
email = StringVar()
mobile = StringVar()
gender = StringVar()
dob = StringVar()
blood_group = StringVar()
address = StringVar()
password = StringVar()
chktc = IntVar()

# Function to Clear Form After Submit
def clear_data():
    entry_1.delete(0, END)
    entry_1_1.delete(0, END)
    entry_2.delete(0, END)
    entry_2_1.delete(0, END)
    entry_2_3.delete(0, END)
    combo_gender.current(0)
    combo_blood.current(0)
    entry_6.delete(0, END)
    entry_7.delete(0, END)

# Register Button Function
def insert_record():
    print(Fullname.get(), user.get(), email.get(), mobile.get(), gender.get(), dob.get() ,blood_group.get(), address.get(), password.get())

    if Fullname.get() == "" or user.get() == "" or email.get() == "" or mobile.get() == "" or gender.get() == "" or dob.get() == "" or blood_group.get() == "" or address.get() == "" or password.get() == "":
        messagebox.showerror("Error !", "All Fields are Required !")
    else:
        import dbconnect
        conn = dbconnect.getsqliteconnection()        # Connect to sqlite database
        try:
            cur = conn.cursor()
            cur.execute("select * from Admin_detail where Emailid=?", (email.get(),))
            row = cur.fetchone()
            if row != None:
                entry_2_1.delete(0, END)
                messagebox.showerror("Error !", "Already Exists Email ! Try with another one.")
            # elif int(age.get()>=18 and age.get()<=65 :
            #     pass
            # else:
            #     print("\tYou cannot Donate!!!")
              
            # elif len(self.mobileno)==10 and self.mobileno.isdigit() :
            #     pass
            # else:
            #     print("\tEntered wrong number")    
            # elif(self.email.count('@')==1  and '.' in self.email ):
            #     pass
            else:
                query = ('insert into Admin_detail(Name, Username, Emailid, MobileNo, Gender, DOB, BloodGroup, Address, Password)'
                         'values (:name1, :user1, :email1, :mobile1, :gender1, :dob1, :bloodg, :addr1, :pass1);')
                params = {
                    'name1': Fullname.get(),
                    'user1': user.get(),
                    'email1': email.get(),
                    'mobile1': mobile.get(),
                    'gender1': gender.get(),
                    'dob1': dob.get(),
                    'bloodg': blood_group.get(),
                    'addr1': address.get(),
                    'pass1': password.get()
                        }
                conn.execute(query, params)
                conn.commit()
                messagebox.showinfo("Success !", "Admin Successfully Registered !")
                clear_data()
        except sqlite3.Error as error:
                print("Problem with SQlite table", error)
        finally:
            if conn:
                conn.close()
                print("The SQLite connection is closed")
     
# Function that checks chkbox is checked or not   
def isChecked():
        if chktc.get() == 1:
           reg_btn['state'] = NORMAL
           reg_btn.configure(text='Submit')
        elif chktc.get() == 0:
           reg_btn['state'] = DISABLED
           reg_btn.configure(text='Check T & C!')

# Label 0
label_0 = Label(root, text="ADMIN REGISTRATION",font=("times new roman", 32, "bold"),fg="white",bg="#f1053c").place(x=50,y=30)

# Label 1
label_1 = Label(root, text="ADMIN  NAME",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=110)
entry_1 = Entry(root,textvar=Fullname,width=32)
entry_1.place(x=270,y=110)

# Label 2
label_1_1 = Label(root, text="USER NAME",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=140)
entry_1_1 = Entry(root,textvar=user,width=32)
entry_1_1.place(x=270,y=140)

# Label 3
label_2 = Label(root, text="EMAIL ID",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=170)
entry_2 = Entry(root,textvar=email,width=32)
entry_2.place(x=270,y=170)

# Label 4
label_2_1 = Label(root, text="MOBILE NO.",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=200)
entry_2_1 = Entry(root,textvar=mobile,width=32)
entry_2_1.place(x=270,y=200)

# Label 5
label_3 = Label(root,text="GENDER",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=230)
combo_gender = ttk.Combobox(root, textvariable=gender)
combo_gender['values'] = ('Male','Female','Transgender')
combo_gender.current(0) # Default 'Male' WILL SELECTED
combo_gender.place(x=270,y=230, width=200)

# Label 6
label_4 = Label(root, text="D.O.B.",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=270)
entry_2_3 = Entry(root,textvar=dob,width=32)
entry_2_3.place(x=270,y=270)

# Label 7
label_5 = Label(root, text="BlOOD  GROUP", font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80, y=310)
combo_blood = ttk.Combobox(root, textvariable=blood_group)
combo_blood['values'] = ('A+','B+','O+','A-','B-','AB+','AB-','O-')
combo_blood.current(0) # Default A+ WILL SELECTED
combo_blood.place(x=270, y=310, width=200)

# Label 8
label_6 = Label(root, text="ADDRESS",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=340)
entry_6 =Entry(root,textvar=address,width=32)
entry_6.place(x=270,y=340)

# Label 9
label_7 = Label(root, text="PASSWORD",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=372)
entry_7 =Entry(root,textvar=password,width=32)
entry_7.place(x=270,y=372)

# Chkbox
chk = Checkbutton(root, text="I Agree the Terms & Conditions",font=(("times new roman",15,"bold")),fg="white",bg="#f1053c", variable=chktc, onvalue=1, offvalue=0, command=isChecked).place(x=130, y=430)

# Style Button
style = ttk.Style()
style.configure('TButton',width=20 )
reg_btn = ttk.Button(root, text='Submit', style='TButton', state=DISABLED, command=insert_record)
reg_btn.place(x=200,y=500)
root.mainloop()         # mainloop() is used to load the GUI Window
