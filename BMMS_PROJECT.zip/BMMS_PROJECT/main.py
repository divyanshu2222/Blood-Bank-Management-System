# Importing
import sqlite3
from tkinter import *
from imp import reload
from PIL import Image, ImageTk
from tkinter import Tk, StringVar, messagebox, END, IntVar, DISABLED, NORMAL

root=Tk()
root.title("Blood Bank Management System")   # Set Title
root.iconbitmap('images\\icon1.ico')         # Set Icon
root.geometry("1199x600+100+50")             # Set Geometry
root.resizable(False,False)                  # Disable the resizable Property
root.configure(bg="#f1053c")                 # Set bg Color

# Set BackGround Image
img = Image.open("images\\admin.png")
img = img.resize((550,620))
my =ImageTk.PhotoImage(img)
label = Label(image=my).place(x=650,y=0)

# Menu Function
def home_page():
    root.destroy()
    import index1

# create a Menubar
menubar = Menu(root)
root.config(menu=menubar)
user_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label='HOME', command=home_page)        # add menu items to the File menu


# Create Variables
user = StringVar()
password = StringVar()

# Clear Data After Update
def clear_data():
    txt_user.delete(0, END)
    txt_pass.delete(0, END)
    

# Login Function
def loginPage():
    print(user.get(), password.get())
    if user.get() == ""  or password.get() == "":
        messagebox.showerror("Error !", "All Fields are Required !")
    else:
        import dbconnect
        conn = dbconnect.getsqliteconnection()  # Connect to sqlite database
        try:
            cur = conn.cursor()
            cur.execute("select * from Admin_detail where Username=? and Password=?", (user.get(),password.get()))
            row = cur.fetchone()
            if row is None:
                messagebox.showerror("Error !", "INVALID User/Password !")
                txt_user.delete(0, END)
                txt_pass.delete(0, END)
            else:
                root.destroy()
                import page2
                reload(page2)
                clear_data()
        except sqlite3.Error as error:
                print("Problem with SQlite table", error)
        finally:
            if conn:
                conn.close()
                print("The SQLite connection is closed")

# Button Functions
def forgotPassword():
    root.destroy()
    import ForgotPassword
    reload(ForgotPassword)
def adminRegistration():
    root.destroy()
    import registrationAdmin
    reload(registrationAdmin)

# Frame
Frame_login=Frame(root,bg="#f1053c",highlightthickness=5,highlightbackground="white").place(x=70,y=40,height=380,width=500)
        
# Label 0
title=Label(root,text="Admin Login",font=("times new roman",35,"bold"),fg="white",bg="#f1053c").place(x=182,y=50)

# Label 1
lb1_user=Label(root,text="Username",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=145,y=140)
txt_user=Entry(root, textvar=user,font=("times new roman",15),bg="lightgray")
txt_user.place(x=145,y=170,width=350,height=35)

# Label 2
lb2_pass=Label(root,text="Password",font=("times new roman",15,"bold"),fg="white",bg="#f1053c").place(x=145,y=210)
txt_pass=Entry(root, textvar=password,font=("times new roman",15),show="*" ,bg="lightgray")
txt_pass.place(x=145,y=240,width=350,height=35)

# Buttons
forget_btn=Button(root,text="Forgotten Password ?",command=forgotPassword,cursor="hand2",bg="#f1053c",bd=0,fg="white",font=("times new roman",12)).place(x=145,y=280)
new_admin =Button(root,text="New Admin ?",command=adminRegistration,cursor="hand2",bg="#f1053c",bd=0,fg="white",font=("times new roman",12)).place(x=145,y=320)
login_btn=Button(root,command=loginPage,cursor="hand2",text="Login",bg="#C70039",fg="white",font=("times new roman",20)).place(x=225,y=398,width=180,height=40)
    
root.mainloop()         # mainloop() is used to load the GUI Window
















# # Login Class
# class Login:
#     def __init__(self,root):
#         self.root=root
#         #----Frame----------->
#         Frame_login=Frame(self.root,bg="#f1053c",highlightthickness=5,highlightbackground="white")
#         Frame_login.place(x=70,y=40,height=510,width=500)
        
#         title=Label(Frame_login,text="Login Here",font=("times new roman",35,"bold"),fg="white",bg="#f1053c").place(x=80,y=30)
#         # desc=Label(Frame_login,text="Admin Login Area",font=("times new roman",15,"bold"),fg="#C70039",bg="white").place(x=80,y=100)

#         lb1_user=Label(Frame_login,text="Username",font=("Goudy old style",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=140)
#         self.txt_user=Entry(Frame_login,font=("times new roman",15),bg="lightgray")
#         self.txt_user.place(x=80,y=170,width=350,height=35)

#         lb2_pass=Label(Frame_login,text="Password",font=("Goudy old style",15,"bold"),fg="white",bg="#f1053c").place(x=80,y=210)
#         self.txt_pass=Entry(Frame_login,font=("times new roman",15),show="*" ,bg="lightgray")
#         self.txt_pass.place(x=80,y=240,width=350,height=35)

#         forget_btn=Button(Frame_login,text="Forget Password?",cursor="hand2",bg="#f1053c",bd=0,fg="white",font=("times new roman",12)).place(x=80,y=280)
#         login_btn=Button(self.root,command=self.login_function,cursor="hand2",text="Login",bg="#C70039",fg="white",font=("times new roman",20)).place(x=195,y=527,width=180,height=40)
    
#     def login_function(self):
#         if self.txt_pass.get()=="" or self.txt_user.get=="":
#             messagebox.showerror("Error","All fields are required !",parent=self.root)
#         elif self.txt_pass.get()=="12345" and self.txt_user.get()=="admin":
#             self.root.destroy()
#             import page2
#         else:
#             self.txt_pass.delete(0,END)
#             self.txt_user.delete(0,END)
#             messagebox.showerror("Error","Invalid Username/Password !",parent=self.root) 
# obj=Login(root)
# root.mainloop()    