# Importing
import sqlite3
from tkinter import*
from imp import reload
from tkinter.font import Font
from PIL import ImageTk,Image
from tkinter import Tk, StringVar, ttk, END, IntVar, DISABLED, NORMAL, messagebox, Button,Toplevel

# Page 2 Function
def page_2():
    window = Tk()
    window.title("Blood Bank Management System")        # Set Title
    window.iconbitmap('images\\icon1.ico')              # Set Icon
    window.geometry("1199x600+100+50")                  # Set Geometry
    window.resizable(False,False)                       # Disable the resizable Property
    window.configure(bg="#f1053c")                      # Set bg Color

# Set Background Image
    img1 = Image.open("images\\donregis.png")
    img1 = img1.resize((600,630))
    my1 =ImageTk.PhotoImage(img1)
    label = Label(image=my1).place(x=600,y=0)

# Menu Functions
    def home_page():
        window.destroy()
        import index1
        reload(index1)

# create a Menubar
    menubar = Menu(window)
    window.config(menu=menubar)
    user_menu = Menu(menubar, tearoff=0)
    menubar.add_cascade(label='HOME',command=home_page)     # add menu items to the File menu

# Button Functions
    def donarCall():
        window.destroy()
        import viewalldonar
        viewalldonar.viewall_record()
    def regis_donar():
        window.destroy()
        import registrationdonar
        reload(registrationdonar)
    def regis_acceptor():
        window.destroy()
        import registrationacceptor
        reload (registrationacceptor)
    def accepterCall():
        window.destroy()
        import viewallreceiver
        viewallreceiver.viewall_record()
    def bloodCall():
        window.destroy()
        import ViewBloodDetail
        ViewBloodDetail.viewall_record()

# Buttons
    b1 = Button(window, text="DONAR REGISTRATION",command=regis_donar, foreground="#f1053c", activebackground="orange",bg='white', width=40, height=2, font=("times new roman", 10, "bold")).place(x=120, y=110)
    b2 = Button(window, text="DONAR DEATILS",command=donarCall, foreground="#f1053c", activebackground="orange",bg='white', width=40, height=2, font=("times new roman", 10, "bold")).place(x=120, y=160)
    b3 = Button(window, text="RECEIVER REGISTRATION",command=accepterCall, foreground="#f1053c", activebackground="orange",bg='white', width=40, height=2,font=("times new roman", 10, "bold")).place(x=120, y=240)
    b4 = Button(window, text="RECEIVER DEATILS",command=regis_acceptor, foreground="#f1053c" , activebackground="orange", bg='white', width=40, height=2,font=("times new roman", 10, "bold")).place(x=120, y=290)
    b5 = Button(window, text="CHECK BLOOD AVAILABILITY",command=bloodCall, foreground="#f1053c" , activebackground="orange", bg='white', width=40, height=2,font=("times new roman", 10, "bold")).place(x=120, y=380)

    window.mainloop()       # mainloop() is used to load the GUI Window
page_2()                    # Function Call




