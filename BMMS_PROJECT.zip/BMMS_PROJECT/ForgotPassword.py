# Importing
import sqlite3
from tkinter import *
from imp import reload
from PIL import ImageTk,Image
from tkinter import Tk, StringVar, messagebox, ttk, END, IntVar, DISABLED, NORMAL

root = Tk()
root.title("Blood Bank Management System")      # set title
root.iconbitmap('images\\icon1.ico')            # set icons
root.geometry("1199x600+100+50")                # set geometry
root.resizable(False, False)                    # Disable the resizable Property
root.configure(bg='#f1053c')                    # set bg color

# Set BackGround Image
img1 = Image.open("images\\donregis.png")
img1 = img1.resize((600,670))
my1 =ImageTk.PhotoImage(img1)
label = Label(image=my1).place(x=600,y=0)

# Menu Function
def login():
    root.destroy()
    import main
    reload(main)

# create a Menubar
menubar = Menu(root)
root.config(menu=menubar)
user_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label='BACK',command=login)  # add menu items to the File menu

# Create Variables
email = StringVar()
password = StringVar()
confirmpass = StringVar()

# Clear Data After Update
def clear_data():
    txt_email.delete(0, END)
    txt_pass.delete(0, END)
    txt_confirmpass.delete(0, END)
    
# Update Button Function
def forgotPassword():
    print(email.get(), password.get(), confirmpass.get())
    if email.get() == ""  or password.get() == "" or confirmpass.get() == "" :
        messagebox.showerror("Error !", "All Fields are Required !")
    else:
        import dbconnect
        conn = dbconnect.getsqliteconnection()  # Connect to sqlite database
        try:
            cur = conn.cursor()
            cur.execute("select * from Admin_detail where Emailid=?", (email.get(),))
            row = cur.fetchone()
            if row is None:
                txt_email.delete(0, END)
                messagebox.showerror("Error !", "INVALID Email !")
            elif password.get() == confirmpass.get():
                cur.execute('update Admin_detail set Password = ? where Emailid = ?',(password.get(),email.get()))
                conn.commit()
                messagebox.showinfo("Success !", "PASSWORD UPDATED !")
                clear_data()
            else:
                txt_pass.delete(0, END)
                txt_confirmpass.delete(0, END)
                messagebox.showerror("Error !", "INVALID Password !")
        except sqlite3.Error as error:
                print("Problem with SQlite table", error)
        finally:
            if conn:
                conn.close()
                print("The SQLite connection is closed")

# Label 0
title =Label(root, text="FORGOT PASSWORD", font=("times new roman", 20, "bold"), foreground="white",bg="#f1053c").place(x=150, y=30)

# Label 1
l_email = Label(root, text="EMAIL ID", font=("times new roman", 11, "bold"), foreground="white",bg="#f1053c").place(x=50, y=100)
txt_email = Entry(root, textvar=email, font=("times new roman", 15,))
txt_email.place(x=220, y=100, width=250)

# Label 2
l_pass = Label(root, text="NEW PASSWORD", font=("times new roman", 11, "bold"), foreground="white",bg="#f1053c").place(x=50, y=140)
txt_pass = Entry(root, textvar=password, show="*", font=("times new roman", 15))
txt_pass.place(x=220, y=140, width=250)

# Label 3
l_confirmpass = Label(root, text="CONFIRM PASSWORD", font=("times new roman", 11, "bold"), foreground="white",bg="#f1053c").place(x=50, y=180)
txt_confirmpass = Entry(root, textvar=confirmpass, font=("times new roman", 15))
txt_confirmpass.place(x=220, y=180, width=250)

# Button
b1 = Button(root, text="UPDATE",command=forgotPassword, foreground="#f1053c", activebackground="orange",bg='white', width=10, height=1, font=("times new roman", 14, "bold")).place(x=280, y=266)

root.mainloop()         # mainloop() is used to load the GUI Window
